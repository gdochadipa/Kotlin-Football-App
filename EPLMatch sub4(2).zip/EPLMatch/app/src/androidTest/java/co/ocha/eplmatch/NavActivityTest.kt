package co.ocha.eplmatch

import android.support.test.espresso.Espresso.onView
import android.support.test.espresso.Espresso.pressBack
import android.support.test.espresso.action.ViewActions.click
import android.support.test.espresso.assertion.ViewAssertions.matches
import android.support.test.espresso.contrib.RecyclerViewActions
import android.support.test.espresso.matcher.ViewMatchers.*
import android.support.test.rule.ActivityTestRule
import android.support.test.runner.AndroidJUnit4
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.widget.RecyclerView
import java.lang.Thread.sleep
import org.jetbrains.anko.Android
import org.junit.Assert.*

import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class NavActivityTest{
    @Rule
    @JvmField var activityRule = ActivityTestRule(NavActivity::class.java)

    @Test
    fun testRecyclerviewBehavior(){
        onView(withId(R.id.listTeam)).check(matches(isDisplayed()))
        onView(withId(R.id.listTeam)).perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(10))
        onView(withId(R.id.listTeam)).perform(
                RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(10, click()))
        sleep(2000)
        onView(withId(R.id.add_to_favorite))
                .check(matches(isDisplayed()))
        onView(withId(R.id.add_to_favorite)).perform(click())
        onView(withText("Added to favorite"))
                .check(matches(isDisplayed()))

        pressBack()


        onView(withId(R.id.navigation)).check(matches(isDisplayed()))
        onView(withId(R.id.navigation_dashboard)).perform(click())
        onView(withId(R.id.list_next)).check(matches(isDisplayed()))
        onView(withId(R.id.list_next)).perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(5))
        onView(withId(R.id.list_next)).perform(
                RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(5, click())
        )
        sleep(2000)
        onView(withId(R.id.add_to_favorite))
                .check(matches(isDisplayed()))
        onView(withId(R.id.add_to_favorite)).perform(click())
        onView(withText("Added to favorite"))
                .check(matches(isDisplayed()))

        pressBack()

        onView(withId(R.id.navigation)).check(matches(isDisplayed()))
        onView(withId(R.id.navigation_favorit)).perform(click())
        onView(withId(R.id.list_event)).check(matches(isDisplayed()))
        onView(withId(R.id.list_event)).perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(1))
        sleep(2000)
        onView(withId(R.id.list_event)).perform(
                RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(1, click())
        )
        sleep(2000)
        onView(withId(R.id.add_to_favorite))
                .check(matches(isDisplayed()))
        onView(withId(R.id.add_to_favorite)).perform(click())
        onView(withText("Removed to favorite"))
                .check(matches(isDisplayed()))

        pressBack()

    }



}