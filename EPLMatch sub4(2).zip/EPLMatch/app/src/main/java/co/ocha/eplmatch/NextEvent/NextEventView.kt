package co.ocha.eplmatch.NextEvent



import co.ocha.eplmatch.Model.NextEventsItem

interface NextEventView{
    fun showLoading()
    fun hideLoading()
    fun showMatchList(data: List<NextEventsItem>)
}