package co.ocha.eplmatch.Model


import com.google.gson.annotations.SerializedName


data class NextMatchResponse(

	@field:SerializedName("events")
	val events: List<NextEventsItem>
)