package co.ocha.eplmatch.LastEvent

import co.ocha.eplmatch.Model.LastEventsItem


interface LastEventView{
    fun showLoading()
    fun hideLoading()
    fun showMatchList(data: List<LastEventsItem>)
}