package co.ocha.eplmatch.NextEvent

import co.ocha.eplmatch.Api.ApiRepository
import co.ocha.eplmatch.Api.MatchDBApi
import co.ocha.eplmatch.Model.NextMatchResponse
import co.ocha.eplmatch.Untils.CoroutinesContextProvider
import com.google.gson.Gson
import kotlinx.coroutines.experimental.async
import org.jetbrains.anko.coroutines.experimental.bg
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.uiThread

class NextEventPresenter(private val gson: Gson,
                         private val apiRepository: ApiRepository,
                         private val view: NextEventView,
                         private val context:CoroutinesContextProvider = CoroutinesContextProvider()){
    fun nextEventList(){
        view.showLoading()
//        doAsync {
//            val data = gson.fromJson(apiRepository.doRequest(MatchDBApi.getNextEvent()),NextMatchResponse::class.java)
//
//            uiThread {
//                view.hideLoading()
//                view.showMatchList(data.events)
//            }
//        }
        async(context.main){
            val data= bg {
                gson.fromJson(apiRepository.doRequest(MatchDBApi.getNextEvent()),NextMatchResponse::class.java)
            }
            view.showMatchList(data.await().events)
            view.hideLoading()
        }
    }
}