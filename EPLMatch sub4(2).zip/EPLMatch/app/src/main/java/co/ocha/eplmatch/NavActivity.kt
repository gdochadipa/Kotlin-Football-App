package co.ocha.eplmatch

import android.os.Bundle
import android.support.design.widget.BottomNavigationView
import android.support.v7.app.AppCompatActivity
import co.ocha.eplmatch.Favorit.FavoritFragment
import co.ocha.eplmatch.Fragment.LastMatchFragment
import co.ocha.eplmatch.Fragment.NextFragment
import kotlinx.android.synthetic.main.activity_nav.*

class NavActivity : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_nav)


         navigation.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_home -> {
                    loadLastMatchFragment(savedInstanceState)

                }
                R.id.navigation_dashboard -> {
                    loadNextMatchFragment(savedInstanceState)

                }

                R.id.navigation_favorit -> {
                    loadFavorit(savedInstanceState)
                }

            }
            true
        }
        navigation.selectedItemId = R.id.navigation_home
//        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener)
    }

    private fun loadLastMatchFragment(savedInstanceState: Bundle?){
        if (savedInstanceState == null){
            supportFragmentManager.beginTransaction()
                    .replace(R.id.main_container,
                            LastMatchFragment(),
                            LastMatchFragment::class.java.simpleName).commit()
        }
    }

    private fun loadNextMatchFragment(savedInstanceState: Bundle?){
        if (savedInstanceState == null){
            supportFragmentManager.beginTransaction()
                    .replace(R.id.main_container,NextFragment(),
                            NextFragment::class.java.simpleName).commit()
        }
    }

    private fun loadFavorit(savedInstanceState: Bundle?){
        if(savedInstanceState == null){
            supportFragmentManager.beginTransaction()
                    .replace(R.id.main_container,FavoritFragment(),
                            FavoritFragment::class.java.simpleName).commit()
        }
    }

}
