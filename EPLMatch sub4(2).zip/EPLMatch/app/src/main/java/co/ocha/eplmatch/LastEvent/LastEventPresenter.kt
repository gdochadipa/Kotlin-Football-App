package co.ocha.eplmatch.LastEvent

import co.ocha.eplmatch.Api.ApiRepository
import co.ocha.eplmatch.Api.MatchDBApi
import co.ocha.eplmatch.Model.LastMatchResponse
import co.ocha.eplmatch.Untils.CoroutinesContextProvider
import com.google.gson.Gson
import kotlinx.coroutines.experimental.async
import org.jetbrains.anko.coroutines.experimental.bg
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.uiThread

class LastEventPresenter(private val view: LastEventView,
                         private val apiRepository: ApiRepository,
                         private val gson: Gson,
                         private val context: CoroutinesContextProvider = CoroutinesContextProvider()){
    fun getMatchList() {
        view.showLoading()
//        doAsync {
//            val data = gson.fromJson(apiRepository.doRequest(MatchDBApi.getLastMatch()),LastMatchResponse::class.java
//            ).events
//
//            uiThread {
//                view.hideLoading()
//                view.showMatchList(data)
//            }
//        }

            async(context.main) {
                val data = bg {
                    gson.fromJson(apiRepository.doRequest(MatchDBApi.getLastMatch()),LastMatchResponse::class.java)
                }
                view.showMatchList(data.await().events)
                view.hideLoading()
            }

    }
}
