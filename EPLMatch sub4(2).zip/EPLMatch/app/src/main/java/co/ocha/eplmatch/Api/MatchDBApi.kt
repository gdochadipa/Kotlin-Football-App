package co.ocha.eplmatch.Api

import android.net.Uri
import co.ocha.eplmatch.BuildConfig

object MatchDBApi{
    fun getLastMatch(): String {
//        val linkLastMatch = Uri.parse(BuildConfig.BASE_URL).buildUpon()
//                .appendPath("api")
//                .appendPath("v1")
//                .appendPath("json")
//                .appendPath(BuildConfig.TSDB_API_KEY)
//                .appendPath("eventspastleague.php")
//                .appendQueryParameter("id","4328")
//                .build()
//                .toString()
//        return linkLastMatch
       return "https://www.thesportsdb.com/api/v1/json/1/eventspastleague.php?id=4328"
    }

    fun getNextEvent():String{
//        val linkNextMatch = Uri.parse(BuildConfig.BASE_URL).buildUpon()
//                .appendPath("api")
//                .appendPath("v1")
//                .appendPath("json")
//                .appendPath(BuildConfig.TSDB_API_KEY)
//                .appendPath("eventsnextleague.php")
//                .appendQueryParameter("id","4328")
//                .build()
//                .toString()

        return "https://www.thesportsdb.com/api/v1/json/1/eventsnextleague.php?id=4328"
    }

    fun getMatchD(idEvent: String?):String?{
//        val linkDetEvent = Uri.parse(BuildConfig.BASE_URL).buildUpon()
//                .appendPath("api")
//                .appendPath("v1")
//                .appendPath("json")
//                .appendPath(BuildConfig.TSDB_API_KEY)
//                .appendPath("lookupevent.php")
//                .appendQueryParameter("id",idEvent)
//                .build()
//                .toString()
        //"https://www.thesportsdb.com/api/v1/json/1/lookupevent.php?id=4328"
      //  "https://www.thesportsdb.com/api/v1/json/1/lookupevent.php?id=$idEvent"
        return "https://www.thesportsdb.com/api/v1/json/1/lookupevent.php?id=$idEvent"
    }

    fun getLookupTeam(idTeam: String?):String{
        val linkLookupTeam = Uri.parse(BuildConfig.BASE_URL).buildUpon()
                .appendPath("api")
                .appendPath("v1")
                .appendPath("json")
                .appendPath(BuildConfig.TSDB_API_KEY)
                .appendPath("lookupteam.php")
                .appendQueryParameter("id",idTeam)
                .build()
                .toString()

        return "https://www.thesportsdb.com/api/v1/json/1/lookupteam.php?id=$idTeam"
    }


}