package co.ocha.eplmatch.NextEvent

import co.ocha.eplmatch.Api.ApiRepository
import co.ocha.eplmatch.Api.MatchDBApi
import co.ocha.eplmatch.LastEvent.LastEventPresenter
import co.ocha.eplmatch.Model.NextEventsItem
import co.ocha.eplmatch.Model.NextMatchResponse
import co.ocha.eplmatch.Untils.TestContextProvider
import com.google.gson.Gson
import org.junit.Before
import org.junit.Test

import org.junit.Assert.*
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.MockitoAnnotations

class NextEventPresenterTest {
    @Mock
    private
    lateinit var view: NextEventView

    @Mock
    private
    lateinit var gson: Gson

    @Mock
    private
    lateinit var apiRepository: ApiRepository

    private lateinit var presenter: NextEventPresenter

    @Before
    fun setUp() {
        MockitoAnnotations.initMocks(this)
        presenter = NextEventPresenter(gson, apiRepository, view, TestContextProvider())
    }

    @Test
    fun nextEventList() {
        val events: MutableList<NextEventsItem> = mutableListOf()
        val response = NextMatchResponse(events)

        Mockito.`when`(gson.fromJson(apiRepository
                .doRequest(MatchDBApi.getNextEvent()),
                NextMatchResponse::class.java
        )).thenReturn(response)

        presenter.nextEventList()

        Mockito.verify(view).showLoading()
        Mockito.verify(view).showMatchList(events)
        Mockito.verify(view).hideLoading()
    }
}