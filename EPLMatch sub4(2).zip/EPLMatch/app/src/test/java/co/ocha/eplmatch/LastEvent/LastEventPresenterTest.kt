package co.ocha.eplmatch.LastEvent

import co.ocha.eplmatch.Api.ApiRepository
import co.ocha.eplmatch.Api.MatchDBApi
import co.ocha.eplmatch.Model.LastEventsItem
import co.ocha.eplmatch.Model.LastMatchResponse
import co.ocha.eplmatch.Untils.TestContextProvider
import com.google.gson.Gson
import kotlinx.coroutines.experimental.test.TestCoroutineContext
import org.junit.Test

import org.junit.Assert.*
import org.junit.Before
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.MockitoAnnotations

class LastEventPresenterTest {
    @Mock
    private
    lateinit var view: LastEventView

    @Mock
    private
    lateinit var gson: Gson

    @Mock
    private
    lateinit var apiRepository: ApiRepository

    private lateinit var presenter: LastEventPresenter

    @Before
    fun setUp() {
        MockitoAnnotations.initMocks(this)
        presenter = LastEventPresenter(view, apiRepository, gson,TestContextProvider())
    }

    @Test
    fun getMatchList() {
        val events: MutableList<LastEventsItem> = mutableListOf()
        val response = LastMatchResponse(events)

        Mockito.`when`(gson.fromJson(apiRepository
                .doRequest(MatchDBApi.getLastMatch()),
                LastMatchResponse::class.java
        )).thenReturn(response)

        presenter.getMatchList()

        Mockito.verify(view).showLoading()
        Mockito.verify(view).showMatchList(events)
        Mockito.verify(view).hideLoading()

    }
}